MDW AI DESIGNER MOCKUP PACK — README

START HERE:
1. MDW_AI_Designer_Prompt_Phase1_FINAL.txt
2. MDW_Figma_Ready_Wireframe_Spec_Phase1_FINAL.txt

PURPOSE:
This package is for directing an AI design system, AI design agent, or AI-assisted designer to produce detailed Phase 1 visual mockups.

AUTHORITATIVE COUNTS:
- Homepage 12
- Cover 9
- Editorial 20
- Beauty 6
- Commercial / ECOM 8
- Red Carpet 18

INCLUDED:
- AI prompt in DOCX and TXT
- Figma-ready wireframe spec in DOCX and TXT
- Complete Designer Handoff Brief
- Updated Designer Package PDF
- Final Copy Deck
- Audited Content Map workbook
- Press kit reference
- Visual Style Guide
